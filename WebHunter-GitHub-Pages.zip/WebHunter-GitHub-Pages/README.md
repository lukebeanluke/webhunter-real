# WebHunter — GitHub Pages / Jekyll

This is a static GitHub Pages-compatible WebHunter site. It needs no Node server or build step.

## Publish with GitHub Pages

1. Create a GitHub repository for the site.
2. Upload `index.html` and `webhunter-custom-sites.json` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select your publishing branch (usually `main`) and folder (`/ (root)`), then save.
5. Open the Pages URL GitHub provides. Jekyll will publish the root `index.html` and the JSON file as static assets.

## Add a website from inside WebHunter

1. Open the published site and press **Add Website**.
2. Enter its name, URL, category and description, then save. The new website is saved in that browser's local storage immediately.
3. To make the new link part of the public site for everyone, press **Export for GitHub Pages** in WebHunter. This downloads `webhunter-custom-sites.json`.
4. Upload that exported file to the repository root, replacing the existing file, and commit the change. Once Pages redeploys, the site loads those links for everyone.

The browser cannot safely write directly into a GitHub repository from a public static page without an authenticated GitHub workflow. The export-and-commit step intentionally avoids putting a GitHub access token in the public website.

## Notes

- The built-in directory contains 700 website entries, including 100 new gaming additions and 100 new additions across other categories.
- Favorites and links added in a browser are stored locally in that browser until exported.
- Live search opens a search engine in a new tab; it does not scrape or import third-party search results into the page.
